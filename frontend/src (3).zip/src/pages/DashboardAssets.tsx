import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AssetTable from "../components/AssetTable";
import AssetModal from "../components/AssetModal";
import { useAssets } from "../context/AssetsContext";

export default function DashboardAssets() {
  const navigate = useNavigate();
  const { user, isLoading } = useAuth();
  const { assets, isLoading: assetsLoading } = useAssets();

  // Redirecionamento seguro
  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/login");
    }
  }, [isLoading, user, navigate]);

  if (isLoading) return <p>Carregando sessão...</p>;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Ativos</h1>
      {assetsLoading ? (
        <p>Carregando ativos...</p>
      ) : (
        <AssetTable data={assets} />
      )}
      <AssetModal />
    </div>
  );
}
