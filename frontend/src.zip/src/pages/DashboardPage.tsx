import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import MaintenanceTable from "../components/MaintenanceTable";
import MaintenanceModal from "../components/MaintenanceModal";
import { useMaintenances } from "../context/MaintenanceContext";
import type { NewMaintenance } from "../interface/MaintenanceInterface";

export default function DashboardPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { maintenances, isLoading, addMaintenance } = useMaintenances();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAssetId, setSelectedAssetId] = useState(""); // futuro filtro por ativo

  return (
    <div>
      <button
        onClick={() => navigate("/assets")}
        className="mb-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
      >
        Ir para Ativos
      </button>
      <h1>Manutenções</h1>

      <button onClick={() => setIsModalOpen(true)}>Nova Manutenção</button>

      {isLoading ? (
        <p>Carregando manutenções...</p>
      ) : (
        <MaintenanceTable data={maintenances} />
      )}

      <MaintenanceModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        assetId={selectedAssetId || "ID_FIXO_PARA_TESTE"}
        onSave={async (data: NewMaintenance) => {
          try {
            await addMaintenance(data);
            setIsModalOpen(false);
          } catch (err: any) {
            alert("Erro ao salvar manutenção: " + err.message);
          }
        }}
      />
    </div>
  );
}
